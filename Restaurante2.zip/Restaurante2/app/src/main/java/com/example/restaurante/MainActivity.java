package com.example.restaurante;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText ed1;
    EditText ed2;
    EditText ed3;
    EditText res1;
    EditText res2;
    EditText res3;
    Button bt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    ed1 = (EditText) findViewById(R.id.edt_consumo);
    ed2 = (EditText) findViewById(R.id.edt_couvert_artistico);
    ed3 = (EditText) findViewById(R.id.edt_dividir);
    res1 = (EditText) findViewById(R.id.edt_servico);
    res2 = (EditText) findViewById(R.id.edt_conta_total);
    res3 = (EditText) findViewById(R.id.edt_valor_pessoa);
    bt1 = (Button) findViewById(R.id.bt_calcular);

    bt1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            double v1;
            double v2;
            double v3;
            double v4;
            double v5;
            double v6;
            Double calc;

            v1 =Double.parseDouble(ed1.getText().toString());
            v2 =Double.parseDouble(ed2.getText().toString());
            v3 =Double.parseDouble(ed3.getText().toString());

            v4 = v1/0.1;
            v5 = v1+v2+v4;
            v6= v5/v3;

            res1.setText(v4.toString());
            res2.setText(v5.toString());
            res3.setText(v6.toString());
        }
    });
    }
}
